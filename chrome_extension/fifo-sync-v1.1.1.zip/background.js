// FIFO Sync — Background Service Worker
// Runs every 6 hours, opens hidden tabs for each connected bank,
// scrapes transactions via content scripts, sends to FIFO backend.

const SYNC_ALARM   = "fifo-sync";
const SYNC_MINUTES = 360; // 6 hours
const DEFAULT_FIFO = "http://localhost:8000";

// ── Startup ───────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(SYNC_ALARM, { periodInMinutes: SYNC_MINUTES });
  log("FIFO Sync installed. Alarm set for every 6 hours.");
});

// Re-register alarm on service worker restart (MV3 workers can be killed)
chrome.alarms.get(SYNC_ALARM, (alarm) => {
  if (!alarm) {
    chrome.alarms.create(SYNC_ALARM, { periodInMinutes: SYNC_MINUTES });
  }
});

// ── Alarm handler ─────────────────────────────────────────────────────────
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) {
    log("Alarm fired — starting sync…");
    syncAllAccounts();
  }
});

// ── Message from popup (manual sync trigger) ──────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "SYNC_NOW") {
    log("Manual sync triggered from popup");
    syncAllAccounts().then(() => sendResponse({ ok: true })).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === "GET_STATUS") {
    chrome.storage.local.get(["lastSync", "lastError", "syncing"], (data) => {
      sendResponse(data);
    });
    return true;
  }
  // Content script asks background to fetch scrape config (avoids localhost permission issue)
  if (msg.type === "GET_SCRAPE_CONFIG") {
    chrome.storage.local.get(["fifoUrl"], async ({ fifoUrl = DEFAULT_FIFO }) => {
      try {
        const r = await fetch(`${fifoUrl}/api/extension/scrape-config?domain=${encodeURIComponent(msg.domain)}`);
        if (!r.ok) { sendResponse({ error: "not_supported" }); return; }
        const config = await r.json();
        sendResponse({ config });
      } catch (e) {
        sendResponse({ error: e.message });
      }
    });
    return true;
  }

  // Bridge script requests a sync for a specific bank (triggered from FIFO demo page)
  if (msg.type === "SMART_CONNECT_SYNC") {
    const { bank_key, apiBase } = msg;
    const fifoUrl = apiBase || DEFAULT_FIFO;
    smartConnectSync(bank_key, fifoUrl, sendResponse);
    return true;
  }
});

// ── Smart Connect sync (triggered from FIFO demo page) ────────────────────
async function smartConnectSync(bank_key, fifoUrl, sendResponse) {
  try {
    // Fetch accounts to find the one matching this bank
    const r = await fetch(`${fifoUrl}/api/accounts`);
    const accounts = await r.json();
    const account = accounts.find(a => a.bank_key === bank_key);

    if (!account) {
      // No account yet — this is a first-time connect, use the bank's start_url
      const cfgResp = await fetch(`${fifoUrl}/api/extension/scrape-config?domain=${encodeURIComponent(_bankKeyToDomain(bank_key))}`);
      if (!cfgResp.ok) { sendResponse({ ok: false, error: `No config for ${bank_key}` }); return; }
      const cfg = await cfgResp.json();
      const startUrl = cfg.start_url;
      if (!startUrl) { sendResponse({ ok: false, error: `No start URL for ${bank_key} — please do a manual login first.` }); return; }
      await syncBank({ id: null, bank_key, display_name: bank_key, last_url: startUrl }, fifoUrl, startUrl, 180_000);
      sendResponse({ ok: true, count: 0 });
      return;
    }

    // Existing account — use last_url
    const startUrl = account.last_url || _bankKeyToStartUrl(bank_key);
    if (!startUrl) { sendResponse({ ok: false, error: "No saved session — please do a manual login first." }); return; }

    await syncBank(account, fifoUrl, startUrl, 180_000);
    sendResponse({ ok: true, count: account.tx_count || 0 });

  } catch (e) {
    sendResponse({ ok: false, error: e.message });
  }
}

function _bankKeyToDomain(bank_key) {
  const map = {
    capital_one: "myaccounts.capitalone.com",
    boa:         "www.bankofamerica.com",
    icici:       "retailnetbanking.icici.bank.in",
    discover:    "card.discover.com",
  };
  return map[bank_key] || "";
}

function _bankKeyToStartUrl(bank_key) {
  const map = {
    capital_one: "https://myaccounts.capitalone.com/accountSummary",
    boa:         "https://www.bankofamerica.com/",
    icici:       "https://retailnetbanking.icici.bank.in/",
  };
  return map[bank_key] || null;
}

// ── Main sync orchestrator ────────────────────────────────────────────────
async function syncAllAccounts() {
  const { fifoUrl = DEFAULT_FIFO } = await chrome.storage.local.get("fifoUrl");

  // Fetch accounts from FIFO backend
  let accounts;
  try {
    const r = await fetch(`${fifoUrl}/api/accounts`);
    accounts = await r.json();
  } catch (e) {
    await setError(`Cannot reach FIFO backend at ${fifoUrl}: ${e.message}`);
    return;
  }

  // Sync each bank we know how to handle
  for (const acct of accounts) {
    try {
      if (acct.bank_key === "capital_one") {
        await syncBank(acct, fifoUrl, "https://myaccounts.capitalone.com/accountSummary", 120_000);
      } else if (acct.bank_key === "icici") {
        if (!acct.last_url) {
          log(`ICICI (account #${acct.id}): no last_url — please do a manual login first.`);
          continue;
        }
        await syncBank(acct, fifoUrl, acct.last_url, 180_000);
      } else if (acct.bank_key === "boa") {
        if (!acct.last_url) {
          log(`BOA (account #${acct.id}): no last_url — please do a manual login first.`);
          continue;
        }
        await syncBank(acct, fifoUrl, acct.last_url, 120_000);
      } else {
        log(`Skipping unsupported bank: ${acct.bank_key}`);
      }
    } catch (e) {
      log(`Error syncing ${acct.bank_key} (account #${acct.id}): ${e.message}`);
    }
  }
}

// ── Generic bank sync (opens a hidden tab, waits for SCRAPE_RESULT) ───────
async function syncBank(account, fifoUrl, startUrl, timeoutMs) {
  log(`Syncing ${account.bank_key} (account #${account.id}) — opening ${startUrl}`);
  await chrome.storage.local.set({ syncing: true });

  let tab;
  try {
    tab = await chrome.tabs.create({ url: startUrl, active: false });

    const result = await waitForScrapeResult(tab.id, timeoutMs);

    if (result.error === "NOT_LOGGED_IN") {
      await setError(`${account.display_name} session expired — please log in in Chrome to refresh your session.`);
      return;
    }
    if (result.error) {
      await setError(`${account.display_name} sync failed: ${result.error}`);
      return;
    }

    log(`Scraped ${result.transactions.length} transactions from ${account.bank_key}, sending to FIFO…`);

    const resp = await fetch(`${fifoUrl}/api/smart-connect/extension-ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        bank_key:       account.bank_key,
        transactions:   result.transactions,
        ending_balance: result.endingBalance || "",
      }),
    });

    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || "FIFO returned an error");

    log(`${account.bank_key} sync complete — ${data.count} transactions stored.`);
    await chrome.storage.local.set({
      lastSync:  new Date().toISOString(),
      lastError: null,
      syncing:   false,
    });

  } catch (e) {
    await setError(e.message);
  } finally {
    if (tab) {
      try { await chrome.tabs.remove(tab.id); } catch (_) {}
    }
    await chrome.storage.local.set({ syncing: false });
  }
}

// ── Wait for content script to scrape and message back ───────────────────
function waitForScrapeResult(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.runtime.onMessage.removeListener(handler);
      reject(new Error(`Timed out waiting for scrape result after ${timeoutMs / 1000}s`));
    }, timeoutMs);

    function handler(msg, sender) {
      if (msg.type === "SCRAPE_RESULT" && sender.tab?.id === tabId) {
        clearTimeout(timer);
        chrome.runtime.onMessage.removeListener(handler);
        resolve(msg.payload);
      }
    }
    chrome.runtime.onMessage.addListener(handler);
  });
}

// ── Helpers ───────────────────────────────────────────────────────────────
async function setError(msg) {
  log("ERROR:", msg);
  await chrome.storage.local.set({ lastError: msg, syncing: false });
}

function log(...args) {
  console.log("[FIFO]", ...args);
}
