// FIFO Sync — Bridge Content Script
// Runs on the FIFO demo page (localhost + production).
// 1. Sets window.__FIFO_EXTENSION so the page knows the extension is installed.
// 2. Listens for FIFO_SMART_CONNECT postMessages from the page.
// 3. Routes sync requests to the background service worker.
// 4. Sends FIFO_SYNC_STATUS updates back to the page.

(function () {
  // ── Signal to the page that the extension is installed ───────────────
  // Content scripts run in an isolated world — their `window` is invisible
  // to the page's JS. We inject a <script> tag into the real DOM so that
  // window.__FIFO_EXTENSION lands in the page's main world where demo.html can see it.
  const _s = document.createElement("script");
  _s.textContent = "window.__FIFO_EXTENSION = true;";
  (document.head || document.documentElement).appendChild(_s);
  _s.remove();

  // ── Listen for sync requests from the FIFO demo page ─────────────────
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.type !== "FIFO_SMART_CONNECT") return;

    const { bank, apiBase } = msg;
    log(`Smart Connect requested for bank: ${bank}, apiBase: ${apiBase}`);

    // Tell the page we're starting
    sendStatus("logging_in");

    // Ask the background to sync this specific bank
    chrome.runtime.sendMessage(
      { type: "SMART_CONNECT_SYNC", bank_key: bank, apiBase },
      (response) => {
        if (chrome.runtime.lastError) {
          sendStatus("error", chrome.runtime.lastError.message);
          return;
        }
        if (!response) {
          sendStatus("error", "No response from extension background.");
          return;
        }
        if (response.status === "scraping") {
          sendStatus("scraping");
        } else if (response.ok) {
          sendStatus("done", null, { count: response.count });
        } else {
          sendStatus("error", response.error || "Sync failed.");
        }
      }
    );
  });

  function sendStatus(status, message, data) {
    window.postMessage({ type: "FIFO_SYNC_STATUS", status, message, data }, "*");
  }

  function log(...args) {
    console.log("[FIFO bridge]", ...args);
  }
})();
