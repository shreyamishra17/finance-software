// FIFO Sync — Universal Content Script
// Works on ALL supported bank pages without any code changes.
// Fetches scraping instructions from the FIFO backend, then executes them.
// To add a new bank: update the backend config — no extension update needed.

(function () {
  const domain = window.location.hostname.toLowerCase();
  const url    = window.location.href;
  log("Universal content script loaded on:", domain, url);

  // Ask background service worker to fetch scrape config (background has network access)
  chrome.runtime.sendMessage({ type: "GET_SCRAPE_CONFIG", domain }, async (response) => {
    if (chrome.runtime.lastError || !response || response.error) {
      // Domain not supported or backend unreachable — silently exit
      log("No config available:", chrome.runtime.lastError?.message || response?.error);
      return;
    }
    log("Got scrape config for", response.config.bank_key);
    await runScrape(response.config, url);
  });
})();

// ── Main scrape runner ────────────────────────────────────────────────────
async function runScrape(config, currentUrl) {
  // ── 1. Check if not logged in ─────────────────────────────────────────
  if (config.login_check && config.login_check.some(p => currentUrl.includes(p))) {
    log("Not logged in — reporting back.");
    chrome.runtime.sendMessage({ type: "SCRAPE_RESULT", payload: { error: "NOT_LOGGED_IN" } });
    return;
  }

  // ── 2. Run any navigation steps (e.g. Capital One: click View More) ───
  for (const step of (config.navigate || [])) {
    if (step.action === "wait_and_click_text") {
      // Only run this step if URL matches the trigger pattern
      if (step.on_url && !urlMatchesPattern(currentUrl, step.on_url)) continue;
      try {
        log(`Navigation: looking for button with texts: ${step.texts.join(", ")}`);
        const el = await waitForAnyText(step.texts, step.timeout || 30000);
        log("Navigation: clicking", el.innerText.trim());
        el.click();
        // Wait for URL to change before continuing
        await sleep(2000);
      } catch (e) {
        log("Navigation step failed (non-fatal):", e.message);
      }
    }
  }

  // ── 3. Wait for ready_url_pattern if specified ────────────────────────
  if (config.ready_url_pattern) {
    try {
      await waitForUrlPattern(config.ready_url_pattern, config.ready_timeout || 60000);
      log("URL pattern matched:", config.ready_url_pattern);
    } catch (e) {
      sendError(`Timed out waiting for page to navigate: ${e.message}`);
      return;
    }
  }

  // ── 4. Wait for transaction rows to appear ────────────────────────────
  log("Waiting for rows:", config.ready_selector);
  try {
    await waitForElement(() => document.querySelector(config.ready_selector), config.ready_timeout || 45000);
  } catch (_) {
    sendError(`No transaction rows found on this page. Please do a manual login from FIFO first so the extension knows which page to open.`);
    return;
  }

  // ── 5. Load all pages ─────────────────────────────────────────────────
  await loadAllPages(config);

  // ── 6. Scrape rows ────────────────────────────────────────────────────
  const transactions = scrapeRows(config);
  const endingBalance = scrapeBalance(config);

  log(`Scraped ${transactions.length} transactions, balance: ${endingBalance}`);
  chrome.runtime.sendMessage({
    type: "SCRAPE_RESULT",
    payload: { transactions, endingBalance, currentUrl: window.location.href },
  });
}

// ── Load all pages before scraping ───────────────────────────────────────
async function loadAllPages(config) {
  if (!config.pagination) return;
  const { type, button_texts, page_info_pattern } = config.pagination;
  const MAX = 50;

  for (let i = 0; i < MAX; i++) {
    let btn = null;

    if (type === "view_more_button") {
      btn = findButtonByTexts(button_texts);
    } else if (type === "next_button") {
      btn = findNextPageButton(button_texts, page_info_pattern);
    }

    if (!btn) break;

    const countBefore = document.querySelectorAll(config.rows.selector).length;
    btn.click();
    try {
      await waitForRowCountChange(config.rows.selector, countBefore, 12000);
    } catch (_) {
      break;
    }
    await sleep(300);
  }
}

// ── Scrape all visible rows using config columns ──────────────────────────
function scrapeRows(config) {
  const rows = document.querySelectorAll(config.rows.selector);
  const results = [];
  const r = config.rows;

  rows.forEach((row) => {
    try {
      let date = "", description = "", amount = "", amountType = "", balance = "", rawAmount = "";

      // Description
      if (r.description) description = firstLine(text(row.querySelector(r.description)));

      // Date
      if (r.date) {
        date = normalizeDate(text(row.querySelector(r.date)));
      } else if (r.date_mode === "parent_walk") {
        date = extractDateByParentWalk(row);
      }

      // Amount & type
      if (r.amount_sign === "credit_debit_cols") {
        const creditTxt = text(row.querySelector(r.credit));
        const debitTxt  = text(row.querySelector(r.debit));
        balance         = text(row.querySelector(r.balance));
        if (creditTxt && creditTxt !== "-" && creditTxt !== "0.00") {
          amount = parseAmount(creditTxt); amountType = "credit"; rawAmount = creditTxt;
        } else if (debitTxt && debitTxt !== "-" && debitTxt !== "0.00") {
          amount = parseAmount(debitTxt);  amountType = "debit";  rawAmount = debitTxt;
        }
      } else if (r.amount_sign === "type_column") {
        const typeTxt = text(row.querySelector(r.amount_type)).toLowerCase();
        rawAmount = text(row.querySelector(r.amount));
        amount = parseAmount(rawAmount);
        amountType = typeTxt.includes("credit") ? "credit" : "debit";
        if (rawAmount.includes("(") || rawAmount.includes("-")) amountType = "debit";
        if (r.balance) balance = text(row.querySelector(r.balance));
      } else {
        // positive_is_debit (Capital One, Discover)
        rawAmount = text(row.querySelector(r.amount));
        const num = parseFloat(rawAmount.replace(/[$,₹€£¥()]/g, "")) || 0;
        amount = String(Math.abs(num));
        amountType = num < 0 ? "credit" : "debit";
      }

      if (!description && !amount) return; // skip empty rows

      const pending = row.classList.contains("pending") ||
                      (date || "").toLowerCase() === "pending";

      results.push({ date, description, amount, amount_type: amountType, raw_amount: rawAmount, balance, pending });
    } catch (_) {}
  });

  return results;
}

// ── Scrape ending balance ─────────────────────────────────────────────────
function scrapeBalance(config) {
  for (const sel of (config.balance_selectors || [])) {
    const el = document.querySelector(sel);
    if (el) {
      const t = el.innerText?.trim();
      if (t && /[\d,]+/.test(t)) return t;
    }
  }
  return "";
}

// ── Date extraction by walking up the DOM (ICICI) ─────────────────────────
function extractDateByParentWalk(row) {
  try {
    let el = row.parentElement;
    for (let i = 0; i < 10; i++) {
      if (!el) break;
      const dateEl = el.querySelector("div.date, div[class*='date']");
      if (dateEl) {
        const day   = dateEl.querySelector("p.date-1, span.date-1")?.innerText?.trim();
        const month = dateEl.querySelector("p.date-2, span.date-2")?.innerText?.trim();
        if (day && month) return normalizeDate(`${day} ${month} ${new Date().getFullYear()}`);
        const full = dateEl.innerText?.trim();
        if (full) return normalizeDate(full);
      }
      const prev = el.previousElementSibling;
      if (prev && /\d{1,2}[\s/-]\w+/i.test(prev.innerText || "")) {
        return normalizeDate(prev.innerText.trim());
      }
      el = el.parentElement;
    }
  } catch (_) {}
  return "";
}

// ── Button finders ────────────────────────────────────────────────────────
function findButtonByTexts(texts) {
  const els = document.querySelectorAll("a, button");
  for (const el of els) {
    const t = el.innerText?.trim().toLowerCase();
    if (texts.includes(t)) return el;
  }
  return null;
}

function findNextPageButton(buttonTexts, pageInfoPattern) {
  for (const el of document.querySelectorAll("button, a, span")) {
    const t = el.innerText?.trim();
    if (buttonTexts.includes(t) && !el.disabled && el.getAttribute("aria-disabled") !== "true") return el;
  }
  if (pageInfoPattern) {
    const re = new RegExp(pageInfoPattern, "i");
    const allEls = Array.from(document.querySelectorAll("*"));
    const pageEl = allEls.find(el => re.test(el.innerText || ""));
    if (pageEl) {
      let sib = pageEl.nextElementSibling;
      while (sib) {
        if ((sib.tagName === "BUTTON" || sib.tagName === "A") && !sib.disabled) return sib;
        sib = sib.nextElementSibling;
      }
    }
  }
  return null;
}

// ── Helpers ───────────────────────────────────────────────────────────────
function text(el) { return el?.innerText?.trim() || ""; }
function firstLine(s) { return (s || "").split("\n")[0].trim(); }

function parseAmount(raw) {
  return String(Math.abs(parseFloat((raw || "").replace(/[₹$€£¥,\s()]/g, "")) || 0));
}

function normalizeDate(raw) {
  if (!raw || raw.toLowerCase() === "pending") return "Pending";
  try {
    const d = new Date(raw);
    if (!isNaN(d)) return d.toISOString().split("T")[0];
    const withYear = new Date(`${raw} ${new Date().getFullYear()}`);
    if (!isNaN(withYear)) return withYear.toISOString().split("T")[0];
  } catch (_) {}
  return raw;
}

function urlMatchesPattern(url, pattern) {
  const re = new RegExp(pattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*"));
  return re.test(url);
}

function waitForUrlPattern(pattern, timeoutMs) {
  return new Promise((resolve, reject) => {
    if (urlMatchesPattern(window.location.href, pattern)) { resolve(); return; }
    const start = Date.now();
    const t = setInterval(() => {
      if (urlMatchesPattern(window.location.href, pattern)) { clearInterval(t); resolve(); }
      else if (Date.now() - start > timeoutMs) { clearInterval(t); reject(new Error("URL pattern timeout")); }
    }, 300);
  });
}

function waitForElement(finder, timeoutMs) {
  return new Promise((resolve, reject) => {
    const el = finder();
    if (el) { resolve(el); return; }
    const start = Date.now();
    const t = setInterval(() => {
      const found = finder();
      if (found) { clearInterval(t); resolve(found); }
      else if (Date.now() - start > timeoutMs) { clearInterval(t); reject(new Error("Element timeout")); }
    }, 400);
  });
}

function waitForAnyText(texts, timeoutMs) {
  return new Promise((resolve, reject) => {
    const find = () => {
      const lc = texts.map(x => x.toLowerCase());
      for (const el of document.querySelectorAll("a, button")) {
        if (lc.includes(el.innerText?.trim().toLowerCase())) return el;
      }
      return null;
    };
    const found = find();
    if (found) { resolve(found); return; }
    const start = Date.now();
    const t = setInterval(() => {
      const el = find();
      if (el) { clearInterval(t); resolve(el); }
      else if (Date.now() - start > timeoutMs) { clearInterval(t); reject(new Error("Text button timeout")); }
    }, 400);
  });
}

function waitForRowCountChange(selector, oldCount, timeoutMs) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const t = setInterval(() => {
      if (document.querySelectorAll(selector).length !== oldCount) { clearInterval(t); resolve(); }
      else if (Date.now() - start > timeoutMs) { clearInterval(t); reject(new Error("Row count timeout")); }
    }, 400);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function sendError(msg) {
  log("ERROR:", msg);
  chrome.runtime.sendMessage({ type: "SCRAPE_RESULT", payload: { error: msg } });
}

function log(...args) { console.log("[FIFO]", ...args); }
